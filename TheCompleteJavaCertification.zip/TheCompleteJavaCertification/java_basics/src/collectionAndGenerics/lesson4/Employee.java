package collectionAndGenerics.lesson4;

public class Employee implements Comparable<Employee> {
    // Properties
	String name;
	int salary;
	String department;
	
	// Constructors
	public Employee(String name, int salary, String department) {
		super();
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
	
	

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + ", department=" + department + "]";
	}



	@Override
	public int compareTo(Employee o) {
		if(this.name.compareTo(o.name) < 0) {
			return -1;
		} else if(this.name.compareTo(o.name)  > 0) {
			return 1;
		}
		return 0;
	}
	
	
}
