package collectionAndGenerics.lesson4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class Application {

	public static void main(String[] args) {
		
		ArrayList<Integer> list1 = new ArrayList<Integer>();
		list1.add(12);
		list1.add(43);
		list1.add(15);
		list1.add(67);
		list1.add(43);
		
		ArrayList<Integer> newList = new ArrayList<Integer>();
		newList.add(15);
		newList.add(12);
		newList.add(43);
//		list1.addAll(newList);
//		list1.clear();
//		list1.removeAll(newList);
//		boolean hasValue = list1.contains(67);
//		boolean hasValue = list1.isEmpty();
		boolean hasValue = list1.retainAll(newList);
		System.out.println(hasValue);
		System.out.println(list1);
		
		// Convert a HashSet into List
		HashSet<Integer> hashSet = new HashSet<Integer>();
		hashSet.add(12);
		hashSet.add(43);
		hashSet.add(15);
		hashSet.add(67);
		hashSet.add(43);
		ArrayList<Integer> li = new ArrayList<Integer>(hashSet);
		System.out.println("Conveted List from HashSet: "+li);
		
		// Sorting a collection
		HashSet<Integer> hashSet2 = new HashSet<Integer>();
		hashSet2.add(12);
		hashSet2.add(43);
		hashSet2.add(15);
		hashSet2.add(67);
		hashSet2.add(43);
		hashSet2.add(10);
		hashSet2.add(10);
		
		ArrayList<Integer> myList = new ArrayList<Integer>(hashSet2);
		Collections.sort(myList);
		System.out.println(myList);
		
		// How above handle to String?
		HashSet<String> hashSet3 = new HashSet<String>();
		hashSet3.add("Random");
		hashSet3.add("Tooth Brush");
		hashSet3.add("Computer");
		hashSet3.add("Cloths");
		
		ArrayList<String> myList2 = new ArrayList<String>(hashSet3);
		Collections.sort(myList2);
		System.out.println(myList2);
		
		// How sort work on user defined Type
		HashSet<Employee> hashSet4 = new HashSet<Employee>();
		hashSet4.add(new Employee("Mike",3500,"Accounting"));
		hashSet4.add(new Employee("Paul",3000,"Admin"));
		hashSet4.add(new Employee("Peter",4000,"IT"));
		hashSet4.add(new Employee("Angel",2000,"Maint"));
		
		
		ArrayList<Employee> myList3 = new ArrayList<Employee>(hashSet4);
		Collections.sort(myList3);
		System.out.println(myList3);
		
		
		

	}

}
