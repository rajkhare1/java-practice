package collectionAndGenerics.lesson3;

import java.util.HashSet;

public class Application {

	public static void main(String[] args) {
		HashSet<Animal> animals = new HashSet<Animal>();
		animals.add(new Animal("DOG",14));
		animals.add(new Animal("CAT",06));
		animals.add(new Animal("DOG",20));
		animals.add(new Animal("DOG",14));
		
		for(Animal  animal : animals) {
			System.out.println(animal);
		}

	}

}
