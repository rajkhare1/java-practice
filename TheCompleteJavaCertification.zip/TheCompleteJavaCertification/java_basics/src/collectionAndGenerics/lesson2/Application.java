package collectionAndGenerics.lesson2;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> animals = new ArrayList<String>();
		animals.add("Lion");
		animals.add("Cat");
		animals.add("Dog");
		animals.add("Bird");
		
		// Traversing the list
		// approach 1: Traditional for loop
//		for(int i = 0; i < animals.size(); i++) {
//			System.out.println(animals.get(i));
//		}
		
		// approach 2: foreach loop
//		for(String animal : animals) {
//			System.out.println(animal);
//		}
		
		// ArrayList With UserDefined Complex Data type
		List<Vehicle> vehicles = new LinkedList<Vehicle>();
		vehicles.add(new Vehicle("Toyata", "Camery",12000, false));
		vehicles.add(new Vehicle("Honda", "Accord",12000, false));
		vehicles.add(new Vehicle("Jeep", "Wrangler",25000, true));
		
		// Traverse the list
		// approch 2: foreach loop
//		for(Vehicle vehicle : vehicles) {
//			System.out.println(vehicle);
//		}
		
		printElements(animals);
		printElements(vehicles);

	}
	
	public static void printElements(List anyList) {
		for(int i = 0; i < anyList.size(); i++) {
			System.out.println(anyList.get(i));
		}
		
	}

}
