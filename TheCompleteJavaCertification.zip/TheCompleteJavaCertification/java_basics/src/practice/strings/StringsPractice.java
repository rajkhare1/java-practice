package practice.strings;

public class StringsPractice {

	public static void main(String[] args) {
		
		String str = "RADHA KRISHNA KRISHNA RADHA";
		int a = str.indexOf("KRISHNA");
		int b = str.lastIndexOf("KRISHNA");

		System.out.println(a);
		System.out.println(b);

	}

}
