package practice.loops;

public class ForLoopPractice {

	public static void main(String[] args) {
		String str = "RajKhareIsAGreatJavaDeveloper";
		String result = reverseString(str);
		System.out.println(result);
		
		//printEvenNumbers();

	}

	private static void printEvenNumbers() {
		for(int i=0; i<=100; i+=2) {
			System.out.println(i);
		}
	}

	private static String reverseString(String str) {
		String revStr = "";
		for(int i = str.length()-1; i>=0 ;i--) {
			revStr += str.charAt(i);
		}
		return revStr;
	}

}
