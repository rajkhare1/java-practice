package practice.loops;

public class DebuggerPractice {

	public static void main(String[] args) {
		
		int count = 0;
		for(int i=0; i<100; i++) {
			System.out.println(i);
			int temp = count + 1;
			count = temp;
		}

	}

}
