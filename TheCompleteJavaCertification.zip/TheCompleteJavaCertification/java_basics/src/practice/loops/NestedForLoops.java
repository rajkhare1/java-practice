package practice.loops;

public class NestedForLoops {

	public static void main(String[] args) {
           int counter = 0;
		for (int idx = 0; idx < 100; idx++) {
			for (int j = 0; j < 100; j++) {
				System.out.println(idx+" ------ "+j);
				counter += 1;
			}
		}
		
		System.out.println("COUNTER: "+counter);

	}

}
