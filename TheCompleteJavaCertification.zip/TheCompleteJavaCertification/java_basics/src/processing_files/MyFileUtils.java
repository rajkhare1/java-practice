package processing_files;

import processing_files.exceptions.FooRuntimeException;

public class MyFileUtils {
	public static int subtract10FromLargerNumber(int number) throws Exception{
		if(number < 10) {
			throw new FooRuntimeException("The number was passed smaller than 10");
		}
		return number - 10;
	}
}


