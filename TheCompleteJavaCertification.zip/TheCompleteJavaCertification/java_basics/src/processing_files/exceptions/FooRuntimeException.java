package processing_files.exceptions;
public class FooRuntimeException extends Exception{

	public FooRuntimeException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}