package processing_files;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Application {

	public static void main(String[] args){
		// TODO Auto-generated method stub
//		for(int i = 0; i <= 3; i++) {
//		Scanner scanner = new Scanner(System.in);
//		System.out.println("Enter some Text: ");
//		String enterdText = scanner.nextLine();
//		System.out.println(enterdText);
//		}
		
		
		try {
			File file = new File("myfile.txt");
			Scanner scanner = new Scanner(file);
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				System.out.println(line);
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File Not Found!");
//			e.printStackTrace();
		}
		
		try {
			System.out.println(MyFileUtils.subtract10FromLargerNumber(15 ));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
