package understanding_oop;

public class Bird extends Animal implements Flyable{

	public Bird(int age, String gender, int weightInLbs) {
		super(age, gender, weightInLbs);
	}

	public void move() {
		System.out.println("Flapping Wings...");
		
	}

	@Override
	public void fly() {
		System.out.println("Bird is flying...");
	}

	
}
