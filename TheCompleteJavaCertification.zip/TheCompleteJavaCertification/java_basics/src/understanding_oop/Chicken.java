package understanding_oop;

public class Chicken extends Bird{

	public Chicken(int age, String gender, int weightInLbs) {
		super(age, gender, weightInLbs);
		// TODO Auto-generated constructor stub
	}
	

}
