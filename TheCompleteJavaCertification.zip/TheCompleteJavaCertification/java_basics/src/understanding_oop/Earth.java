package understanding_oop;

public class Earth {

	public static void main(String[] args) {
		Human tom = new Human("Tom Cruise",37,157,"brown");
		tom.speak();

	}

}
