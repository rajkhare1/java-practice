package understanding_oop;

public interface Flyable {

	// abstract method
	public void fly();
}
