package understanding_oop;

public class Zoo {

	public static void main(String[] args) {
		Flyable sparrow = new Sparrow(1, "M", 2);
		Flyable bird = new Bird(2, "F", 4);
		
		flyForGeneral(sparrow);
		flyForGeneral(bird);
	}
	
	public static void flyForGeneral(Flyable fly) {
		fly.fly();
	}
}
