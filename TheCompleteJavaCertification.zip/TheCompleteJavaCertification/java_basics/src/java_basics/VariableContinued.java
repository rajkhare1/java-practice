package java_basics;

public class VariableContinued {
	
	public static void main(String[] args) {
		int var = 1000000000;
		long bigNumber = 1000000000000000000l;
		short shortNumber = -32768;
		byte reallySmallNumber = -128;
		double decimalVariable = 202.3434;
		char letter = '8';
	}

}
