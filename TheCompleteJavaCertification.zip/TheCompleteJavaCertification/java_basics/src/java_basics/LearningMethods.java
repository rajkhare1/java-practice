package java_basics;

public class LearningMethods {

	public static void main(String[] args) {
		
	//MyUtils.add10(10);
		MyUtils myVar;
		myVar = new MyUtils();
		System.out.println(myVar.add10(10));
		
		MyUtils.printSomeJunk(87);
		
	
   }
}