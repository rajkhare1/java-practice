package java_basics;

public class ControlFlow {
	public static void main(String[] args) {
		
		boolean hungry = true;
		
		if(hungry) {
			System.out.println("I am starving...");
		} else {
			System.out.println("I'm not hungry");
		}
		
		int hungerRating = 5;
		if(!(hungerRating != 6)) {
			System.out.println("Not hungry");
		}else {
			System.out.println("I am starving...");
		}
		
		int favouriteTemp = 75;
		int currentTemp = 100;
		String opinion;
	if(favouriteTemp ==currentTemp ) {	
		if(currentTemp < favouriteTemp -30) {
			opinion = "It's pretty Darn Cold...";
		} else if(currentTemp > favouriteTemp + 10) {
			opinion = "It's hot out";

		}else {
			opinion = "its's a beautiful day...";

		}
	} else {
		opinion = "unknown temperature";
	}
		System.out.println(opinion);
		
		
		int month = 6;
		String monthString;
		
		switch(month) {
		
		case 6:
			monthString = "June";
			break;
		default : 
			monthString = "all month are goods";
			break;
		}
		
		System.out.println(monthString);
		
		
	}// end main

}//end class
