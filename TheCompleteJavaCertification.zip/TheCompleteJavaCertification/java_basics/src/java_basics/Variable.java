package java_basics;

public class Variable {

	public static void main(String[] args) {
		
		int x = 34;
		System.out.println(x);
		
		x = 234;
		System.out.println(x * 4);
		System.out.println(x);
		
		String words = "this is a sentence";
		System.out.println(words+" these are some more words");

	}

}
