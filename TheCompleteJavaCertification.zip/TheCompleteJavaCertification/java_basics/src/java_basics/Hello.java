package java_basics;

public class Hello {
	
	public static void main(String[] args) {
		//how to print to the screen
		System.out.println("Hello World!");
	}

}
