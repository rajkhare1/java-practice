package java_basics;

public class MyUtils {
	
	public static  String printSomeJunk(String arguments) {
		return arguments;
	}
	
	public static  void printSomeJunk(int arguments) {
		System.out.println(arguments);
	}
	
	public static void sum2Numbers(int firstArg, int secondArg) {
		System.out.println(firstArg + secondArg);
	}
	
	public  int add10(int someArgument) {
		int result = someArgument + 10;
		return result;
	}

} 
