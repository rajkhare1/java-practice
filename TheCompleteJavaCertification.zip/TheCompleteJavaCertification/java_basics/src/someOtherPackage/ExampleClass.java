package someOtherPackage;

import java_basics.MyUtils;

public class ExampleClass {

	public static void doSomething() {
		MyUtils.printSomeJunk(87);
	}
}
