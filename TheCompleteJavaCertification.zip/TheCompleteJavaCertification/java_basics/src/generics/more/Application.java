package generics.more;

import java.util.ArrayList;
import java.util.List;

public class Application {

	public static void main(String[] args) {
		
		Object myObject = new Object();
		String myVar = "Hello";
		myObject = myVar;
		
		Employee emp = new Employee();
		Accountant acc = new Accountant();
		emp = acc;
		
		ArrayList<Employee> employees = new ArrayList<>();
		employees.add(new Employee());
		ArrayList<Accountant> accountants = new ArrayList<>();
		accountants.add(new Accountant());
		
//		employees = accountans;
		
		ArrayList<?> employees2 = new ArrayList<>();
		ArrayList<String> accountants2 = new ArrayList<>();
		employees2 = accountants2;
		
		// This is the upper bound we can not have greater than Employee
		ArrayList<? extends Employee> employees3 = new ArrayList<>();
        ArrayList<Accountant> accountants3 =  new ArrayList<>();
        employees3 = accountants3;
        
        // Lower bound we can put either Employee or its super class.
        ArrayList<? super Employee> employee4 = new ArrayList<>();
        ArrayList<Object> accountant4 = new ArrayList<>();
        employee4 = accountant4;
        
        makeEmployeeWork(accountants);
	}
	
	public static void makeEmployeeWork(List<? extends Employee> employees) {
		for(HRManager emp: (ArrayList<HRManager>)employees) {

			
		}
	}

}
