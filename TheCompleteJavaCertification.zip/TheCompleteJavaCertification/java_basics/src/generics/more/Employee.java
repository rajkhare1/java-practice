package generics.more;

public class Employee {
	
//	public void work() {
//		System.out.println("Employee working!");
//	}

}
