package generics.more;

public class Accountant extends Employee{
	
	public void work() {
		System.out.println("Accountant working!");
	}
}
