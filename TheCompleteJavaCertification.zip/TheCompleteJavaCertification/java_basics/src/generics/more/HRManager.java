package generics.more;

public class HRManager extends Employee{

}
