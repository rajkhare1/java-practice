package generics;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ClientApplication {

	public static void main(String[] args) {
		
//		ArrayList<String> myList = new ArrayList<>();
//		myList.add("Hello");
////		myList.add(100);
////		myList.add(false);
//		
//		String myVal = (String) myList.get(0);
//		
//		// problem without generics
//		String myVal2 = (String) myList.get(1);
		
		Container<Integer, String> container = new Container<>(12, "Raj");
		Integer item1 = container.getItem1();
		String item2 = container.getItem2();
		
		Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3, 4, 5));
		Set<Integer> set2 = new HashSet<>(Set.of(6, 7, 8, 9, 10));
		
		System.out.println(union(set1, set2));
		
		Set<String> strSet1 = new HashSet<>();
		strSet1.add("first");
		strSet1.add("second");
		strSet1.add("whatever");
		
		Set<String> strSet2 = new HashSet<>();
		strSet2.add("first");
		strSet2.add("second");
		strSet2.add("Computer");
		
		Set<String> resultSet = union(strSet1, strSet2);
	    Iterator<String> itr = resultSet.iterator();
	    while(itr.hasNext()) {
	    	System.out.println(itr.next());
	    }

	}
	
	public static <E> Set<E> union(Set<E> set1, Set<E> set2) {
		Set<E> result = new HashSet<>(set1);
		result.addAll(set2);
		return result;
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
