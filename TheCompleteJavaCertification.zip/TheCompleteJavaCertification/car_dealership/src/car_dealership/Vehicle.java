package car_dealership;

public class Vehicle {
	private String modelNo;
	private double price;
	private String color;
	private char insurance;
	
	public Vehicle(String modelNo, double price, String color, char insurance) {
		super();
		this.modelNo = modelNo;
		this.price = price;
		this.color = color;
		this.insurance = insurance;
	}

	public String getModelNo() {
		return modelNo;
	}

	public double getPrice() {
		return price;
	}

	public String getColor() {
		return color;
	}

	public char getInsurance() {
		return insurance;
	}

	@Override
	public String toString() {
		return "Vehicle [modelNo=" + modelNo + ", price=" + price + ", color=" + color + ", insurance=" + insurance
				+ "]";
	}
	
	
	
	
}
