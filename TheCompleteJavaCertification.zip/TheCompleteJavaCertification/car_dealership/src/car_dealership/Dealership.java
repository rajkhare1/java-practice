package car_dealership;

public class Dealership {

	public static void main(String[] args) {
		Customer cust1 = new Customer("Raj Khare", "Miyapur, Hyderabad", 875000, 'Y');
		Vehicle vehicle = new Vehicle("Maruti SX4", 1200000, "Red", 'Y');
		Employee employee = new Employee();
		
		cust1.purchaseCar(vehicle, employee, false);

	}

}
