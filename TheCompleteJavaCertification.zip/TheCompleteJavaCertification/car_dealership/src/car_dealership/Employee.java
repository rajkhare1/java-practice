package car_dealership;

public class Employee {
	
	public void handleCusotmer(Customer cust, Vehicle vehicle, boolean finance) {
		if(finance == true) {
			double loanAmount = vehicle.getPrice() - cust.getCashOnHand();
			runCreaditHistory(cust, loanAmount );
		} else if (vehicle.getPrice() <= cust.getCashOnHand()) {
			processTransaction(cust, vehicle);
		} else {
			System.out.println("tell customer bring more money");
		}
	}
	
	public void runCreaditHistory(Customer cust, double loanAmount ) {
		System.out.println("Ran credit history for Customer...");
		System.out.println("Customer has been approved to purchase the vehicle");
	}
	
	public void processTransaction(Customer cust, Vehicle vehicle) {
		System.out.println("Customer has has purchased the vehicle: "+vehicle+" for the price "
				+vehicle.getPrice()  );
	}
}
