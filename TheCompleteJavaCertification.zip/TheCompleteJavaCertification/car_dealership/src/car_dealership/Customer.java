package car_dealership;

public class Customer {
	private String name;
	private String address;
	private double cashOnHand;
	private char hasAadhar;
	
	
	
	public Customer(String name, String address, double cashOnHand, char hasAadhar) {
		super();
		this.name = name;
		this.address = address;
		this.cashOnHand = cashOnHand;
		this.hasAadhar = hasAadhar;
	}



	public String getName() {
		return name;
	}



	public String getAddress() {
		address += "Dealership City";
		return address;
	}



	public double getCashOnHand() {
		cashOnHand += 500;
		return cashOnHand;
	}



	public char getHasAadhar() {
		return hasAadhar;
	}



	public void purchaseCar(Vehicle vehicle, Employee employee, boolean finance) {
		employee.handleCusotmer(this, vehicle, finance);
	}

}
